#ifndef __DUOJI_
#define __DUOJI_
#include "sys.h"
void DealDegree(u16 Degree);

#endif
