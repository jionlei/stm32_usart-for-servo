	//delay_ms(10);	 
		if (i == 0)
		{
			TIM_SetCompare1(TIM2,350);			//�޸ıȽ�ֵ���޸�ռ�ձ�
		//	LED1 = 0;
			i = 1;
			delay_ms(2000);
		}
		else if (i == 1)
		{
			TIM_SetCompare1(TIM2,575);			//�޸ıȽ�ֵ���޸�ռ�ձ�
		//	LED1 = 0;
			i = 2;
			delay_ms(2000);
		}
		else if (i == 2)
		{
			TIM_SetCompare1(TIM2,800);			//�޸ıȽ�ֵ���޸�ռ�ձ�
		//	LED1 = 0;
			i = 3;
			delay_ms(2000);
		}
		else if (i == 3)
		{
			TIM_SetCompare1(TIM2,1025);
		//	LED1 = 1;
			i = 4;
			delay_ms(2000);
		
		}
		else if (i == 4)
		{
			TIM_SetCompare1(TIM2,1250);
		//	LED1 = 1;
			i = 5;
			delay_ms(2000);
		
		}
		else
		{
				TIM_SetCompare1(TIM2,1400);
		//	LED1 = 1;
			i = 0;
			delay_ms(2000);
		
		}